import 'package:flutter/material.dart';
import 'package:project/main_home.dart';

class CreateProfile extends StatefulWidget {
  const CreateProfile({Key? key}) : super(key: key);

  @override
  State<CreateProfile> createState() => _CreateProfile();
}

class _CreateProfile extends State<CreateProfile> {
  List interest = [
    {"title": "Startups", "value": "1"},   {"title": "Hi-Tech", "value": "3"},
    {"title": "Funding", "value": "2"},   {"title": " Real Estate", "value": "4"},
    {"title": "Capital Market", "value": "5"},   {"title": "Entrepreneurship", "value": "6"},
    {"title": "Alternative investments", "value": "7"}
  ];
  List betterTopics = [
    {"title": "Self discipline", "value": "1"},   {"title": "Risk Management", "value": "3"},
    {"title": "Nature working", "value": "2"},   {"title": "Investments", "value": "4"},
    {"title": "Capital market investments", "value": "5"},   {"title": "Real estate investments", "value": "6"},
    {"title": "Negotiation", "value": "7"}, {"title": "Entrepreneurship", "value": "8"},
    {"title": "Other...", "value": "9"}

  ];
  List age = [
    {"title": "18", "value": "1"},    {"title": "19", "value": "2"},
    {"title": "20", "value": "3"},    {"title": "21", "value": "4"},
    {"title": "22", "value": "5"},    {"title": "23", "value": "6"},
    {"title": "24", "value": "7"},    {"title": "25", "value": "8"},
    {"title": "26", "value": "9"},    {"title": "27", "value": "10"},
    {"title": "28", "value": "11"},    {"title": "29", "value": "12"},
    {"title": "30", "value": "13"},    {"title": "31", "value": "14"},
    {"title": "32", "value": "15"},    {"title": "33", "value": "16"},
    {"title": "34", "value": "17"},    {"title": "35", "value": "18"},
    {"title": "36", "value": "19"},    {"title": "37", "value": "20"},
    {"title": "38", "value": "21"},    {"title": "39", "value": "22"},
    {"title": "40", "value": "23"},    {"title": "41", "value": "24"},
    {"title": "42", "value": "25"},    {"title": "43", "value": "26"},
  ];
  String defaultValue = "";
  String secondDropDown = "";
  bool isChecked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ListView(children: [
          Container(
            margin: const EdgeInsets.only(top: 30,left: 20),
              child: const Text(": Build your profile and set the goals you want to achieve")
          ),
          const SizedBox(
            height: 20,
          ),
          InputDecorator(
            decoration: InputDecoration(
              border:
              OutlineInputBorder(borderRadius: BorderRadius.circular(15.0)),
              contentPadding: const EdgeInsets.all(10),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                  isDense: true,
                  value: defaultValue,
                  isExpanded: true,
                  menuMaxHeight: 350,
                  items: [
                    const DropdownMenuItem(
                        value: "",
                        child: Text(
                          "Select Age",
                        )),
                    ...age.map<DropdownMenuItem<String>>((data) {
                      return DropdownMenuItem(
                          value: data['value'],
                          child: Text(data['title']));
                    }).toList(),
                  ],
                  onChanged: (value) {
                    // print("selected Value $value");
                    setState(() {
                      defaultValue = value!;
                    });
                    }),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          InputDecorator(
            decoration: InputDecoration(
              border:
              OutlineInputBorder(borderRadius: BorderRadius.circular(15.0)),
              contentPadding: const EdgeInsets.all(10),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                  isDense: true,
                  value: secondDropDown,
                  isExpanded: true,
                  menuMaxHeight: 350,
                  items: [
                    const DropdownMenuItem(
                        value: "",
                        child: Text(
                          "Main areas of interest",
                        )),
                    ...interest.map<DropdownMenuItem<String>>((data) {
                      return DropdownMenuItem(
                          value: data['value'],
                          child: Text(data['title']));
                    }).toList(),
                  ],
                  onChanged: (value) {
                    setState(() {
                      secondDropDown = value!;
                    });
                  }),
            ),
          ),
          const SizedBox(
            height: 20,
          ),

          InputDecorator(
            decoration: InputDecoration(
              border:
              OutlineInputBorder(borderRadius: BorderRadius.circular(15.0)),
              contentPadding: const EdgeInsets.all(10),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                  isDense: true,
                  value: secondDropDown,
                  isExpanded: true,
                  menuMaxHeight: 350,
                  items: [
                    const DropdownMenuItem(
                        value: "",
                        child: Text(
                          "Topics you want to get better at",
                        )),
                    ...betterTopics.map<DropdownMenuItem<String>>((data) {
                      return DropdownMenuItem(
                          value: data['value'],
                          child: Text(data['title']));
                    }).toList(),
                  ],
                  onChanged: (value) {
                    setState(() {
                      secondDropDown = value!;
                    });
                  }),
            ),
          ),
          const SizedBox(
            height: 20,
          ),

          InputDecorator(
            decoration: InputDecoration(
              border:
              OutlineInputBorder(borderRadius: BorderRadius.circular(15.0)),
              contentPadding: const EdgeInsets.all(10),
            ),
            child: const TextField(
              decoration: InputDecoration(
                  hintText: "A goal you want to achieve",
                border: InputBorder.none
              ),
            ),
          ),

          Row(
            children: [
              Checkbox(checkColor: Colors.white,
                fillColor: MaterialStateProperty.resolveWith((states) {
                  return Colors.blue;
                }),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(25))
                ),
                value: isChecked,
                onChanged: (bool? value) {
                  setState(() {
                    isChecked = value!;
                  });
                },
              ),
              const Text("Hidden"),

            Row(

              children: [
                Container(
                  margin: const EdgeInsets.only(left: 70),
                    child: const Text("Add another Goal")),
                IconButton(
                      onPressed: (){},
                      icon: const Icon(Icons.add)),
              ],
            )
            ],
          ),

          Container(
            height: 150,
            width: 250,
            decoration: BoxDecoration(
                border: Border.all(color: Colors.black,width: 2),
                borderRadius: const BorderRadius.all(Radius.circular(5))),
            child: const TextField(
              maxLines: 8,
              keyboardType: TextInputType.multiline,
              decoration: InputDecoration(contentPadding: EdgeInsets.only(left: 15.0,top: 10,bottom: 5),hintText: "Where do you want to be in another 5 years "),
            ),
          ),
          
          Row(
            children: [
              Container(
                margin: const EdgeInsets.only(left: 25,top: 50),
                child: TextButton(
                  onPressed: (){},
                  child: const Text('Continue later',
                      style: TextStyle(color: Colors.blue,
                        decoration: TextDecoration.underline,
                        decorationThickness: 2,
                        ),
                  )),
              ),
            Container(
              height: 40,
              width: 130,
              margin: const EdgeInsets.only(left: 50,top: 50),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => const MainHome()));
                },
                  style: const ButtonStyle(
                    backgroundColor: MaterialStatePropertyAll(Colors.redAccent),
                    shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(25),bottomRight: Radius.circular(25)))),
                      elevation: MaterialStatePropertyAll(5)),
              child: const Text("Save",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.normal
              ),)),
            )
            ],
          ),
        ]),
      ),
    );
  }
}