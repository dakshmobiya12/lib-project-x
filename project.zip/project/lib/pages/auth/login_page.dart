// ignore_for_file: avoid_print, unused_import, use_build_context_synchronously

import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:project/main_home.dart';

import '../../helper/helper_function.dart';
import '../../services/auth_services.dart';
import '../../services/database_service.dart';
import '../../widgets/widget.dart';

class Loginpage extends StatefulWidget {
  const Loginpage({Key? key}) : super(key: key);

  @override
  State<Loginpage> createState() => _Loginpage();
}

class _Loginpage extends State<Loginpage> {
  final formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  AuthService authService = AuthService();
  bool _obscureText = true;
  String email = "";
  String password = "";

// Sorry gys i will make it 10 % only so lets start it

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: _isLoading
          ? Center(
              child: CircularProgressIndicator(
                  color: Theme.of(context).primaryColor),
            )
          : Center(
              child: Column(children: <Widget>[
              Container(
                  padding: const EdgeInsets.only(
                      left: 0.0, top: 50.0, right: 0.0, bottom: 0.0),
                  child: const Text(
                    "Welcome to Project X",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
                  )),
              const SizedBox(
                  width: 150,
                  height: 150,
                  child: Image(
                    image: AssetImage(
                      "assets/login.png",
                    ),
                  )),
              Form(
                key: formKey,
                child: Column(
                  children: [
                    Container(
                      width: 250,
                      margin: const EdgeInsets.only(top: 50),
                      child: TextField(
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.email),
                          border: OutlineInputBorder(),
                          labelText: 'Email Address',
                          hintText: 'Email Address',
                        ),
                        keyboardType: TextInputType.emailAddress,
                        onChanged: (value) {
                          setState(() {
                            email = value;
                          });
                        },
                      ),
                    ),
                    Container(
                      width: 250,
                      margin: const EdgeInsets.only(top: 10),
                      child: TextField(
                        decoration: InputDecoration(
                            suffixIcon: InkWell(
                                onTap: () {
                                  setState(() {
                                    if (_obscureText == true) {
                                      _obscureText = false;
                                    } else {
                                      _obscureText = true;
                                    }
                                  });
                                },
                                child: Icon(_obscureText
                                    ? Icons.visibility_sharp
                                    : Icons.visibility_off)),
                            prefixIcon: const Icon(Icons.lock),
                            border: const OutlineInputBorder(),
                            hintText: 'Password',
                            labelText: 'Password'),
                        keyboardType: TextInputType.number,
                        obscureText: _obscureText,
                        maxLength: 6,
                        onChanged: (value) {
                          setState(() {
                            password = value;
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                  margin: const EdgeInsets.only(left: 130),
                  child: TextButton(
                    onPressed: () {},
                    child: const Text(
                      'Forgot Password?',
                      style: TextStyle(
                          color: Colors.lightBlue,
                          decorationStyle: TextDecorationStyle.wavy),
                    ),
                  )),
              Container(
                width: 200,
                margin: const EdgeInsets.only(top: 20),
                child: TextButton(
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(25))),
                    elevation: MaterialStateProperty.all(5),
                    backgroundColor: MaterialStateProperty.all(Colors.green),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      'Log In',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 20.0, color: Colors.white),
                    ),
                  ),
                  onPressed: () {
                    login();
                  },
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: SizedBox(
                  width: 250,
                  child: TextButton(
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25))),
                      elevation: MaterialStateProperty.all(5),
                      backgroundColor:
                          MaterialStateProperty.all(Colors.blueAccent),
                    ),
                    child: const Text(
                      'Facebook Connect',
                      style: TextStyle(fontSize: 20.0, color: Colors.white),
                    ),
                    onPressed: () async {
                      final LoginResult result = await FacebookAuth.instance
                          .login(); // by default we request the email and the public profile
// or FacebookAuth.i.login()
                      if (result.status == LoginStatus.success) {
                        // you are logged
                        print('success');
                        _isLoading = true;
                        final OAuthCredential credential =
                            FacebookAuthProvider.credential(
                                result.accessToken!.token);
                        FirebaseAuth.instance.signInWithCredential(credential);
                      } else {
                        print(result.status);
                        print(result.message);
                      }

                      setState(() {});
                    },
                  ),
                ),
              ),
            ])),
      bottomSheet: Row(
        children: [
          Container(
            margin: const EdgeInsets.only(left: 30, bottom: 50),
            child: TextButton(
              onPressed: () {},
              child: const Text(
                'About us',
                style: TextStyle(
                  decoration: TextDecoration.underline,
                  decorationThickness: 2,
                  color: Colors.blue,
                ),
              ),
            ),
          ),
          Container(
            color: Colors.blueGrey,
            height: 15,
            margin: const EdgeInsets.only(left: 10, bottom: 50),
            width: 2,
          ),
          Container(
            margin: const EdgeInsets.only(left: 10, bottom: 50),
            child: TextButton(
              onPressed: () {},
              child: const Text(
                'Terms',
                style: TextStyle(
                  decoration: TextDecoration.underline,
                  decorationThickness: 2,
                  color: Colors.blue,
                ),
              ),
            ),
          ),
          Container(
            color: Colors.blueGrey,
            height: 15,
            margin: const EdgeInsets.only(left: 10, bottom: 50),
            width: 2,
          ),
          Container(
            margin: const EdgeInsets.only(left: 10, bottom: 50),
            child: TextButton(
              onPressed: () {},
              child: const Text(
                "What is Project X",
                style: TextStyle(
                  decoration: TextDecoration.underline,
                  decorationThickness: 2,
                  color: Colors.blue,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  login() async {
    if (formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      await authService
          .loginWithUserNameandPassword(email, password)
          .then((value) async {
        if (value == true) {
          QuerySnapshot snapshot = await DatabaseService(
                  userId: FirebaseAuth.instance.currentUser!.uid)
              .gettingUserData(email);
          // saving the values to our shared preferences
          await HelperFunction.saveUserLoggedInStatus(true);
          await HelperFunction.saveUserEmailSF(email);
          await HelperFunction.saveUserNameSF(snapshot.docs[0]['fullName']);
          nextScreenReplace(context, const MainHome());
        } else {
          showSnackbar(context, Colors.red, value);
          setState(() {
            _isLoading = false;
          });
        }
      });
    }
  }
}
