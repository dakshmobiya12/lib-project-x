// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import '../../helper/helper_function.dart';
import '../../services/auth_services.dart';
import '../../widgets/widget.dart';
import 'build_your_profile.dart';

void main() {
  runApp(const SignUpPage());
}

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  State<SignUpPage> createState() => _SignUpPage();
}

class _SignUpPage extends State<SignUpPage> {
  bool _isLoading = false;
  final formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";
  String fullName = "";
  AuthService authService = AuthService();
  bool pass = true;
  bool confirmPass = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // resizeToAvoidBottomInset: false,
        body: _isLoading
            ? Center(
                child: CircularProgressIndicator(
                    color: Theme.of(context).primaryColor))
            : SingleChildScrollView(
                child: Center(
                    child: Column(children: <Widget>[
                      Container(
                      padding: const EdgeInsets.only(
                          left: 0.0, top: 30.0, right: 0.0, bottom: 0.0),
                      child: const Text(
                        "Sign Up",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 25),
                      )),
                       const Text("Create an account. It's free"),
                        const SizedBox(
                    height: 50,
                  ),
                      Form(
                        key: formKey,
                        child: Column(
                        children: <Widget>[
                         SizedBox(
                          width: 285,
                          child: TextField(
                            onChanged: (value) {
                              setState(() {
                                fullName = value;
                              });
                            },
                            keyboardType: TextInputType.name,
                            decoration: const InputDecoration(
                                labelText: "Username",
                                contentPadding: EdgeInsets.symmetric(
                                    vertical: 0, horizontal: 10),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey),
                                ),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey))),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                         SizedBox(
                          width: 285,
                          child: TextField(
                            onChanged: (value) {
                              setState(() {
                                email = value;
                              });
                            },
                            keyboardType: TextInputType.emailAddress,
                            decoration: const InputDecoration(
                                labelText: "Email Address",
                                contentPadding: EdgeInsets.symmetric(
                                    vertical: 0, horizontal: 10),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey),
                                ),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey))),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        SizedBox(
                          width: 285,
                          child: TextField(
                            onChanged: (value) {
                              setState(() {
                                password = value;
                              });
                            },
                            decoration: InputDecoration(
                              labelText: "Password",
                              suffixIcon: InkWell(
                                  onTap: () {
                                    setState(() {
                                      if (pass == true) {
                                        pass = false;
                                      } else {
                                        pass = true;
                                      }
                                    });
                                  },
                                  child: Icon(pass
                                      ? Icons.visibility_sharp
                                      : Icons.visibility_off)),
                              prefixIcon: const Icon(Icons.lock),
                              border: const OutlineInputBorder(),
                            ),
                            keyboardType: TextInputType.number,
                            obscureText: pass,
                            maxLength: 6,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        SizedBox(
                          width: 285,
                          child: TextField(
                            maxLength: 6,
                            obscureText: confirmPass,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                                labelText: "Confirm Password",
                                suffixIcon: InkWell(
                                    onTap: () {
                                      setState(() {
                                        if (confirmPass == true) {
                                          confirmPass = false;
                                        } else {
                                          confirmPass = true;
                                        }
                                      });
                                    },
                                    child: Icon(confirmPass
                                        ? Icons.visibility_sharp
                                        : Icons.visibility_off)),
                                prefixIcon: const Icon(Icons.lock),
                                contentPadding: const EdgeInsets.symmetric(
                                    vertical: 0, horizontal: 10),
                                enabledBorder: const OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey),
                                ),
                                border: const OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey))),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                    ],
                  ),
                      ),
                  SizedBox(
                    width: 200,
                    child: TextButton(
                      style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(25))),
                        elevation: MaterialStateProperty.all(5),
                        backgroundColor:
                            MaterialStateProperty.all(Colors.green),
                      ),
                      child: const Padding(
                        padding: EdgeInsets.only(bottom: 6),
                        child: Text(
                          'Sign Up',
                          style: TextStyle(fontSize: 20.0, color: Colors.white),
                        ),
                      ),
                      onPressed: () {
                        register();
                      },
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(right: 125, top: 20),
                    child: const Text(
                      'Recommended:',
                    ),
                  ),
                  SizedBox(
                    width: 250,
                    child: TextButton(
                      style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(25))),
                        elevation: MaterialStateProperty.all(5),
                        backgroundColor:
                            MaterialStateProperty.all(Colors.blueAccent),
                      ),
                      child: const Text(
                        'Facebook Connect',
                        style: TextStyle(fontSize: 20.0, color: Colors.white),
                      ),
                      onPressed: () {},
                    ),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  Row(
                    children: [
                      Container(
                        margin: const EdgeInsets.only(left: 30, top: 60),
                        child: TextButton(
                          onPressed: () {},
                          child: const Text(
                            'About us',
                            style: TextStyle(
                              decoration: TextDecoration.underline,
                              decorationThickness: 2,
                              color: Colors.blue,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        color: Colors.blueGrey,
                        height: 15,
                        margin: const EdgeInsets.only(left: 10, top: 60),
                        width: 2,
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 10, top: 60),
                        child: TextButton(
                          onPressed: () {},
                          child: const Text(
                            'Terms',
                            style: TextStyle(
                              decoration: TextDecoration.underline,
                              decorationThickness: 2,
                              color: Colors.blue,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        color: Colors.blueGrey,
                        height: 15,
                        margin: const EdgeInsets.only(left: 10, top: 60),
                        width: 2,
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 10, top: 60),
                        child: TextButton(
                          onPressed: () {},
                          child: const Text(
                            "What is Project X",
                            style: TextStyle(
                              decoration: TextDecoration.underline,
                              decorationThickness: 2,
                              color: Colors.blue,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ])),
              ));
  }

  register() async {
    if (formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      await authService
          .registerUserWithEmailAndPassword(fullName, email, password)
          .then((value) async {
        if (value == true) {
          // saving the shared preference state
          await HelperFunction.saveUserLoggedInStatus(true);
          await HelperFunction.saveUserEmailSF(email);
          await HelperFunction.saveUserNameSF(fullName);
          signUp(context);
          // nextScreenReplace(context, const CreateProfile());
        } else {
          showSnackbar(context, Colors.red, value);
          setState(() {
            _isLoading = false;
          });
        }
      });}
  }
  void signUp(context) {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => const CreateProfile()));
  }
}

