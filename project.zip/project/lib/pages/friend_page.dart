import 'dart:core';
import 'package:flutter/material.dart';

import '../model/friend_feed_model.dart';

class FriendPage extends StatefulWidget {
  const FriendPage({Key? key}) : super(key: key);

  @override
  State<FriendPage> createState() => _FriendPageState();
}

class _FriendPageState extends State<FriendPage> {
  List<FriendModel> posts = [
    FriendModel("daksh","new goal",20,"10% reduce",'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png'),
    FriendModel("ori kiosk","new goal",50,"Reduce expenses by 10%",'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png'),
    FriendModel("mayank","new goal",20,"10% reduce",'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png'),
    FriendModel("heeralal","new goal",10,"10% reduce",'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png'),
    FriendModel("dream","new goal",50,"10% reduce",'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png'),
    FriendModel("danish","new goal",10,"10% reduce",'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png'),
    FriendModel("bheruji","new goal",100,"10% reduce",'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png'),
  ];


  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: Container(
        padding: const EdgeInsets.only(top: 10,bottom: 25,left: 25,right: 25),
        child: ListView.separated(
            itemBuilder: (context, index) {
              return Center(
                child: Container(
                  decoration: BoxDecoration(borderRadius: const BorderRadius.all(Radius.circular(11)),border: Border.all(color: Colors.black)),
                  child: Column(
                    children: [
                        Container(
                          height: 45,
                          decoration: const BoxDecoration(color: Colors.lightBlue,borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10))),
                          child: Row(children: [
                            const SizedBox(width: 10,),
                            CircleAvatar(backgroundImage: NetworkImage(posts[index].profilePicture.toString()),),
                            const SizedBox(width: 10,),
                            Column(
                              children: [
                                Text(posts[index].userID.toString(),style: const TextStyle(fontWeight: FontWeight.bold)),
                                Text(posts[index].postTitle.toString(),style: const TextStyle(color: Colors.white70)),
                              ],
                            ),
                            const SizedBox(width: 150,),
                            const Icon(Icons.person)
                          ]),
                        ),
                      Container(
                        height: 70,
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(posts[index].postText.toString()),
                      ),
                      Container(
                        height: 40,
                        decoration: const BoxDecoration(color: Colors.lightBlue,borderRadius: BorderRadius.only(bottomRight: Radius.circular(10),bottomLeft: Radius.circular(10))),
                        child: Row(children: [
                          const SizedBox(width: 50,),
                         const Icon(Icons.thumb_up_alt_outlined),Text(posts[index].likes.toString()),
                          const SizedBox(width: 100,),
                          const Icon(Icons.comment)
                        ]),
                      ),
                    ],
                  ),
                ),
              );
            },
            separatorBuilder: (context, index) => const Divider(height: 1,),
            itemCount: posts.length),
      ),
    );
  }
}
