import 'package:flutter/material.dart';
class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePage();
}

class _HomePage extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
          padding: const EdgeInsets.only(top: 10,bottom: 25,left: 25,right: 25),
          child: ListView.separated(
              itemBuilder: (context, index) {
                return Center(
                  child: Container(
                    decoration: BoxDecoration(borderRadius: const BorderRadius.all(Radius.circular(11)),border: Border.all(color: Colors.black)),
                    child: Column(
                      children: [
                        Container(
                          height: 45,
                          decoration: const BoxDecoration(borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10))),
                          child: Row(children:  const[
                            SizedBox(width: 100),
                                Text("Your goal status",style: TextStyle(fontWeight: FontWeight.bold)),
                                SizedBox(width: 70),
                                Icon(Icons.person)
                              ],
                            ),
                          ),
                        const Text('Generate another NIS 50,000 in passive income'),
                        const SizedBox(height: 10),
                        const SizedBox(width: 200,child: LinearProgressIndicator(color: Colors.blue,minHeight: 8,value: 0.50)),
                        const SizedBox(height: 10),
                      ],
                    ),
                  ),
                );
              },
              separatorBuilder: (context, index) => const Divider(height: 1,),
              itemCount: 1),
        ),
    );
  }
}
