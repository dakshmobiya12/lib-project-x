import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:project/main_home.dart';
import 'package:project/pages/auth/signup_page.dart';
import 'package:project/widgets/constants.dart';
import 'helper/helper_function.dart';
import 'pages/auth/login_page.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) {
    // await FacebookAuth.i.webInitialize(
    //   appId: constant().facebookAppId,
    //   cookie: true,
    //   xfbml: true,
    //   version: "v13.0",
    // );

    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: constant().apiKey,
            authDomain: constant().authDomain,
            projectId: constant().projectId,
            storageBucket: constant().storageBucket,
            messagingSenderId: constant().messagingSenderId,
            appId: constant().firebaseAppId));
  } else {
    await Firebase.initializeApp();
  }
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'welcome page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  bool _isLoggedIn = false;
  // make function in class
  @override
  void initState() {
    super.initState();
    getUserLoggedInStatus();
  }

  getUserLoggedInStatus() async {
    await HelperFunction.getUserLoggedInStatus().then((value) {
      if (value != null) {
        _isLoggedIn = value;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: _isLoggedIn
          ? const MainHome()
          : Scaffold(
              body: SingleChildScrollView(
                child: Center(
                    child: Column(children: <Widget>[
                  Container(
                      margin: const EdgeInsets.all(25),
                      padding: const EdgeInsets.only(
                          left: 0.0, top: 30.0, right: 0.0, bottom: 0.0),
                      child: const Text(
                        "Welcome to Project X",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 25),
                      )),
                  Container(
                      decoration: ShapeDecoration(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      width: 250,
                      child: const Image(
                        image: AssetImage(
                          "assets/apk_icon.png",
                        ),
                      )),
                  Container(
                    width: 250,
                    margin: const EdgeInsets.only(top: 80),
                    child: TextButton(
                      style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(25))),
                        elevation: MaterialStateProperty.all(5),
                        backgroundColor:
                            MaterialStateProperty.all(Colors.lightBlue),
                      ),
                      child: const Text(
                        'Log In',
                        style: TextStyle(fontSize: 20.0, color: Colors.white),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Loginpage()));
                      },
                    ),
                  ),
                  Container(
                    width: 250,
                    margin: const EdgeInsets.only(top: 15),
                    child: TextButton(
                      style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(25))),
                        elevation: MaterialStateProperty.all(5),
                        backgroundColor:
                            MaterialStateProperty.all(Colors.green),
                      ),
                      child: const Text(
                        'Sign Up',
                        style: TextStyle(fontSize: 20.0, color: Colors.white),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const SignUpPage()));
                      },
                    ),
                  ),
                ])),
              ),
              bottomSheet: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 30, bottom: 50),
                    child: TextButton(
                      onPressed: () {},
                      child: const Text(
                        'About us',
                        style: TextStyle(
                          decoration: TextDecoration.underline,
                          decorationThickness: 2,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    color: Colors.blueGrey,
                    height: 15,
                    margin: const EdgeInsets.only(left: 10, bottom: 50),
                    width: 2,
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 10, bottom: 50),
                    child: TextButton(
                      onPressed: () {},
                      child: const Text(
                        'Terms',
                        style: TextStyle(
                          decoration: TextDecoration.underline,
                          decorationThickness: 2,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    color: Colors.blueGrey,
                    height: 15,
                    margin: const EdgeInsets.only(left: 10, bottom: 50),
                    width: 2,
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 10, bottom: 50),
                    child: TextButton(
                      onPressed: () {},
                      child: const Text(
                        "What is Project X",
                        style: TextStyle(
                          decoration: TextDecoration.underline,
                          decorationThickness: 2,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
