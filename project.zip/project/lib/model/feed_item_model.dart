import 'package:flutter/cupertino.dart';

class ContentModel{
  String? text;
  String? image;
  IconData? icon;
  int likes;
  bool? isLiked;
    ContentModel(this.text,this.image,this.icon,this.likes,this.isLiked);
}