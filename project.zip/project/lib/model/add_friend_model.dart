
class SearchFriendModel{
  String? profilePicture;
  String? name;
  int age;
  String? mainAresOfInterest;

  SearchFriendModel(this.profilePicture,this.mainAresOfInterest,this.name,this.age);
}