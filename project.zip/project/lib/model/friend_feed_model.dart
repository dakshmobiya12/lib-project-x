// ignore_for_file: unused_import

import 'package:flutter/cupertino.dart';

class FriendModel{
  String? profilePicture;
  String? userID;
  String? postTitle;
  String? postText;
  int? likes;

  FriendModel(this.userID,this.postTitle,this.likes,this.postText,this.profilePicture);
}