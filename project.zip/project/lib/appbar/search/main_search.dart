// ignore_for_file: prefer_is_empty

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../model/add_friend_model.dart';
import '../../model/feed_item_model.dart';
import '../navbar.dart';

class MainSearch extends StatefulWidget {
  const MainSearch({Key? key}) : super(key: key);

  @override
  State<MainSearch> createState() => _MainSearchState();
}

class _MainSearchState extends State<MainSearch> {
  int? groupValue = 0;
  bool _isOnTab = false;

  late final ValueChanged<String> onChanged;
  static List<SearchFriendModel> items = [
    SearchFriendModel(
        'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png',
        ' Real estate developer',
        'Ori kiosk',
        25),
    SearchFriendModel(
        'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png',
        ' Real estate developer',
        'Project X',
        30),
    SearchFriendModel(
        'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png',
        ' Real estate developer',
        'Rajesh',
        35),
    SearchFriendModel(
        'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png',
        ' Real estate developer',
        'Mayank',
        20),
    SearchFriendModel(
        'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png',
        ' Android Developer',
        'Daksh',
        40),
    SearchFriendModel(
        'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png',
        ' FullStack Developer',
        'Dream',
        22),
    SearchFriendModel(
        'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png',
        ' Flutter Expert',
        'Daksh',
        20),
    SearchFriendModel(
        'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png',
        ' Digital Marketing',
        'Kartik',
        20)
  ];
  List<SearchFriendModel> _filteredProducts = List.from(items);

  static List<ContentModel> secondItems = [
    ContentModel(
        "this is item1", "assets/apk_icon.png", Icons.info, 10, true),
    ContentModel(
        "this is item2", "assets/login.png", Icons.newspaper, 20, true,),
    ContentModel(
        "this is item3", "assets/login.png", Icons.newspaper, 50, true,),
  ];
  void _updateProductList(String value) {
    setState(() {
      _filteredProducts = items
          .where((element) =>
              element.name!.toLowerCase().contains(value.toLowerCase()))
          .toList();
    });
  }

  void _updateSecondProductList(String value) {
    setState(() {
      _SecondFilteredProducts = secondItems
          .where((element) =>
              element.text!.toLowerCase().contains(value.toLowerCase()))
          .toList();
    });
  }

  // ignore: non_constant_identifier_names
  List<ContentModel> _SecondFilteredProducts = List.from(secondItems);
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Scaffold(
          drawer: const NavBar(),
          appBar: AppBar(
            centerTitle: true,
            title: SizedBox(
              height: 40,
              child: TextField(
                onChanged: (value) => _isOnTab
                    ? _updateSecondProductList(value)
                    : _updateProductList(value),
                decoration: const InputDecoration(
                  filled: true,
                  fillColor: Colors.black12,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(8.0)),
                      borderSide: BorderSide.none),
                  hintText: "Search",
                ),
              ),
            ),
            actions: [
              IconButton(
                  onPressed: () {
                    showMenu(
                        context: context,
                        position: const RelativeRect.fromLTRB(100, 50, 50, 25),
                        items: [
                          PopupMenuItem(
                              child: Wrap(
                            children: const [
                              Icon(Icons.person_add_alt_1),
                              SizedBox(width: 10),
                              Text('New friend request')
                            ],
                          )),
                          PopupMenuItem(
                              child: Wrap(
                            children: const [
                              Icon(Icons.edit),
                              SizedBox(width: 10),
                              Text('New Task')
                            ],
                          )),
                          PopupMenuItem(
                              child: Wrap(
                            children: const [
                              Icon(Icons.wechat_rounded),
                              SizedBox(width: 10),
                              Text('New massage')
                            ],
                          )),
                          PopupMenuItem(
                              child: Wrap(
                            children: const [
                              Icon(Icons.info_outline),
                              SizedBox(width: 10),
                              Text('New Info')
                            ],
                          )),
                          PopupMenuItem(
                              child: Wrap(
                            children: const [
                              Icon(Icons.newspaper),
                              SizedBox(width: 10),
                              Text('New News')
                            ],
                          )),
                        ]);
                  },
                  icon: const Icon(Icons.notifications)),
              IconButton(onPressed: () {}, icon: const Icon(Icons.wechat_sharp))
            ],
          ),
/*--------------------------------------------------------------------------------------------------------------------------*/
          body: Center(
            child: Padding(
              padding: _isOnTab
                  ? const EdgeInsets.only(left: 20.0, right: 20.0)
                  : const EdgeInsets.all(0.0),
              child: Column(
                children: [
                  Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.all(10),
                    child: CupertinoSlidingSegmentedControl<int>(
                      padding: const EdgeInsets.all(8),
                      groupValue: groupValue,
                      children: const {
                        0: Text("People"),
                        1: Text("Content"),
                      },
                      onValueChanged: (value) {
                        setState(() {
                          groupValue = value;
                          if (value == 1) {
                            _isOnTab = true;
                          } else {
                            _isOnTab = false;
                          }
                        });
                      },
                    ),
                  ),

                  /*---------------------------------------------------------------------------------------------------*/
                  _isOnTab
                      ? Expanded(
                          child: _SecondFilteredProducts.length == 0
                              ? Center(
                                  child: Column(
                                  children: [
                                    Image.asset("assets/page_not_found.png"),
                                    const Text(
                                      "Not Content found!",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ),
                                  ],
                                ))
                              : ListView.separated(
                                  itemBuilder: (context, index) {
                                    return Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: Colors.black, width: 1.1),
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(5))),
                                      child: Column(
                                        children: [
                                          SizedBox(
                                            height: 226,
                                            child: Column(
                                              children: [
                                                Container(
                                                  margin: const EdgeInsets.only(
                                                      top: 0),
                                                  // color: const Color.fromRGBO(158, 158, 158,0.25),
                                                  decoration:
                                                      const ShapeDecoration(
                                                    shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius.only(
                                                                topRight: Radius
                                                                    .circular(
                                                                        5),
                                                                topLeft: Radius
                                                                    .circular(
                                                                        5))),
                                                    color: Colors.redAccent,
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      const SizedBox(
                                                        width: 25,
                                                      ),
                                                      SizedBox(
                                                          width: 210.8,
                                                          child: Text(
                                                            _SecondFilteredProducts[
                                                                    index]
                                                                .text
                                                                .toString(),
                                                            maxLines: 1,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: const TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold),
                                                          )),
                                                      Icon(
                                                        _SecondFilteredProducts[
                                                                index]
                                                            .icon,
                                                        size: 25,
                                                      )
                                                    ],
                                                  ),
                                                ),
                                                
                                              Container(
                                                      height: 150,
                                                      decoration: BoxDecoration(
                                                          border: Border.all(
                                                              color: Colors
                                                                  .black12)),
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left: 5,
                                                              right: 5),
                                                      child: Image.network(
                                                          _SecondFilteredProducts[
                                                                  index]
                                                              .image
                                                              .toString())),
                                                const Divider(),
                                                Container(
                                                  height: 30,
                                                  decoration:
                                                      const ShapeDecoration(
                                                    shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius.only(
                                                                bottomRight:
                                                                    Radius
                                                                        .circular(
                                                                            5),
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                        5))),
                                                    color: Colors.redAccent,
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      const SizedBox(
                                                        width: 50,
                                                        height: 0,
                                                      ),
                                                      InkWell(
                                                          onTap: () {
                                                            setState(() {
                                                              if (_SecondFilteredProducts[
                                                                      index]
                                                                  .isLiked!) {
                                                                _SecondFilteredProducts[
                                                                        index]
                                                                    .likes += 1;
                                                                _SecondFilteredProducts[
                                                                            index]
                                                                        .isLiked =
                                                                    false;
                                                              } else if (!_SecondFilteredProducts[
                                                                      index]
                                                                  .isLiked!) {
                                                                _SecondFilteredProducts[
                                                                        index]
                                                                    .likes -= 1;
                                                                _SecondFilteredProducts[
                                                                        index]
                                                                    .isLiked = true;
                                                              }
                                                            });
                                                          },
                                                          child: Icon(
                                                            _SecondFilteredProducts[
                                                                        index]
                                                                    .isLiked!
                                                                ? Icons
                                                                    .thumb_up_alt_outlined
                                                                : Icons
                                                                    .thumb_up,
                                                            size: 25,
                                                            color: Colors.white,
                                                          )),
                                                      Text(
                                                          _SecondFilteredProducts[
                                                                  index]
                                                              .likes
                                                              .toString(),
                                                          style:
                                                              const TextStyle(
                                                                  color: Colors
                                                                      .white)),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    );
                                  },
                                  separatorBuilder: (context, index) =>
                                      const Divider(),
                                  itemCount: _SecondFilteredProducts.length))
                      : Expanded(
                          child: _filteredProducts.length == 0
                              ? Center(
                                  child: Column(
                                  children: [
                                    Image.asset("assets/page_not_found.png"),
                                    const Text(
                                      "Not People found!",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ),
                                  ],
                                ))
                              : Container(
                                  padding: const EdgeInsets.all(20),
                                  child: ListView.separated(
                                    separatorBuilder: (context, index) =>
                                        const Divider(),
                                    itemBuilder: (context, index) {
                                      return Container(
                                        decoration: const BoxDecoration(
                                            color: Color.fromRGBO(
                                                158, 158, 158, 0.25),
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(10))),
                                        child: ListTile(
                                          trailing: SizedBox(
                                            height: 35,
                                            child: TextButton(
                                              style: ButtonStyle(
                                                elevation:
                                                    MaterialStateProperty.all(
                                                        5),
                                                backgroundColor:
                                                    MaterialStateProperty.all(
                                                        Colors.lightBlue),
                                              ),
                                              child: const Text(
                                                'Massage',
                                                style: TextStyle(
                                                    fontSize: 15.0,
                                                    color: Colors.white),
                                              ),
                                              onPressed: () {},
                                            ),
                                          ),
                                          leading: CircleAvatar(
                                            child: ClipOval(
                                              child: Image.network(
                                                _filteredProducts[index]
                                                    .profilePicture
                                                    .toString(),
                                                fit: BoxFit.cover,
                                                width: 50,
                                                height: 50,
                                              ),
                                            ),
                                          ),
                                          title: Text(
                                              'Name: ${_filteredProducts[index].name.toString()}'),
                                          subtitle: Wrap(
                                              direction: Axis.vertical,
                                              children: [
                                                const SizedBox(height: 5),
                                                Text(
                                                    'Age : ${_filteredProducts[index].age}'),
                                                const SizedBox(height: 5),
                                                Text(
                                                    'Interest : ${_filteredProducts[index].mainAresOfInterest}'),
                                              ]),
                                        ),
                                      );
                                    },
                                    itemCount: _filteredProducts.length,
                                  ),
                                ))
                ],
              ),
            ),
          ),
        ));
  }
}
