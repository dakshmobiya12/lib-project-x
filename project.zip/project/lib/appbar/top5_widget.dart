import 'package:flutter/material.dart';
class Top5Widget extends StatefulWidget {
  const Top5Widget({Key? key}) : super(key: key);

  @override
  State<Top5Widget> createState() => _Top5WidgetState();
}

class _Top5WidgetState extends State<Top5Widget> {
  bool selected = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Top 5 Widget")),

      body: GestureDetector(
        onTap: () {
          setState(() {
            selected = !selected;
          });
        },
        child: Center(
          child: AnimatedContainer(
            height: selected ? 100 : 200,
            width: selected ? 150 : 200,
            color: selected ? Colors.blueGrey : Colors.redAccent,
            alignment: selected ? Alignment.center : Alignment.topCenter,
            duration: const Duration(seconds: 2),
            child: Text(selected ? "center" : "top center"),
          ),
        ),
      ),
    );
  }
}
