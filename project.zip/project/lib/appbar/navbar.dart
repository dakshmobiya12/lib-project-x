import 'package:flutter/material.dart';
import 'package:project/helper/helper_function.dart';
import 'package:project/main_home.dart';

class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}
class _NavBarState extends State<NavBar> {
  String email = "";
  String name = "";
  @override
  void initState() {
    super.initState();
    gettingUserData();
  }
  gettingUserData() async {
    await HelperFunction.getUserEmailFromSF().then((value) {
      setState(() {
        email = value!;
      });
    });
    await HelperFunction.getUserNameFromSF().then((value) {
      setState(() {
        name = value!;
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    return Drawer(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(25))),
      child: ListView(
        // Remove padding
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text(name),
            accountEmail: Text(email),
            currentAccountPicture: CircleAvatar(
              child: ClipOval(
                child: Image.network(
                  'https://oflutter.com/wp-content/uploads/2021/02/girl-profile.png',
                  fit: BoxFit.cover,
                  width: 90,
                  height: 90,
                ),
              ),
            ),
            decoration: const BoxDecoration(
              color: Colors.blue,
              image: DecorationImage(
                  fit: BoxFit.fill,
                  image: NetworkImage(
                      'https://oflutter.com/wp-content/uploads/2021/02/profile-bg3.jpg')),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.home_outlined),
            title: const Text('Home'),
            onTap:() {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const MainHome()));
            },
          ),
          ListTile(
            leading:const  Icon(Icons.perm_contact_calendar_outlined),
            title: const Text('Private Profile'),
            onTap: () {

            },
          ),
          ListTile(
            leading: const Icon(Icons.attach_money),
            title: const Text('Financial Management'),
            onTap: () {

            },
          ),
          const ListTile(
            leading: Icon(Icons.task_alt),
            title: Text('Task list'),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.insert_chart_rounded),
            title: const Text('Investment tracking'),
            onTap: () {

            },
          ),
          ListTile(
            leading: const Icon(Icons.save),
            title: const Text('Saves content'),
            onTap: () {

            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Setting'),
            onTap: () {

            },
          ),
          ListTile(
            leading: const Icon(Icons.info),
            title: const Text('Help '),
            onTap: () {

            },
          ),
        ],
      ),
    );
  }
}