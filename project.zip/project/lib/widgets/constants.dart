class constant{
  String apiKey = "AIzaSyB-siHcQa6T10n6ahZEJ3XrAy78RQ0dhtk";
  String authDomain = "project-x-71e3f.firebaseapp.com";
  String projectId = "project-x-71e3f";
  String storageBucket = "project-x-71e3f.appspot.com";
  String messagingSenderId = "754468417123";
  String firebaseAppId = "1:754468417123:web:115f318123d42c5ceb9256";
  String facebookAppId = "1526873377773253";

}