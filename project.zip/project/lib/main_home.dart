import 'package:flutter/material.dart';
import 'pages/home_page.dart';
import 'pages/news_page.dart';
import 'pages/friend_page.dart';
import 'appbar/navbar.dart';
import 'appbar/search/main_search.dart';

class MainHome extends StatefulWidget {
  const MainHome({Key? key}) : super(key: key);

  @override
  State<MainHome> createState() => _MainHome();
}

class _MainHome extends State<MainHome> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        drawer: const NavBar(),
        appBar: AppBar(
          bottom: const TabBar(
            tabs: [
              Tab(text: "Home", height: 50),
              Tab(text: "News", height: 50),
              Tab(text: "Friend", height: 50)
            ],
          ),
          actions: [
            IconButton(
                onPressed: () {
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const MainSearch()));
                },
                icon: const Icon(Icons.search)),
            IconButton(
                onPressed: () {
                  showMenu(
                      context: context,
                      position: const RelativeRect.fromLTRB(100, 50, 50, 25),
                      items: [
                        PopupMenuItem(
                            child: Wrap(
                          children: const [
                            Icon(Icons.person_add_alt_1),
                            SizedBox(width: 10),
                            Text('New friend request')
                          ],
                        )),
                        PopupMenuItem(
                            child: Wrap(
                          children: const [
                            Icon(Icons.edit),
                            SizedBox(width: 10),
                            Text('New Task')
                          ],
                        )),
                        PopupMenuItem(
                            child: Wrap(
                          children: const [
                            Icon(Icons.wechat_rounded),
                            SizedBox(width: 10),
                            Text('New massage')
                          ],
                        )),
                        PopupMenuItem(
                            child: Wrap(
                          children: const [
                            Icon(Icons.info_outline),
                            SizedBox(width: 10),
                            Text('New Info')
                          ],
                        )),
                        PopupMenuItem(
                            child: Wrap(
                          children: const [
                            Icon(Icons.newspaper),
                            SizedBox(width: 10),
                            Text('New News')
                          ],
                        )),
                      ]);
                },
                icon: const Icon(Icons.notifications)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.wechat_sharp))
          ],
        ),
        // !----------------------------------------------------------------------------------------------------*/

        body: const Center(
          child: TabBarView(
            children: [
              HomePage(),
              NewsPage(),
              FriendPage(),
            ],
          ),
        ),

        floatingActionButtonLocation: FloatingActionButtonLocation.startDocked,
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            showMenu(
                context: context,
                position: const RelativeRect.fromLTRB(20, 450, 100, 25),
                items: [
                  PopupMenuItem(
                      child: Wrap(
                    children: const [
                      Icon(Icons.push_pin),
                      SizedBox(width: 10),
                      Text('New task')
                    ],
                  )),
                  PopupMenuItem(
                      child: Wrap(
                    children: const [
                      Icon(Icons.money_outlined),
                      SizedBox(width: 10),
                      Text('New expense')
                    ],
                  )),
                  PopupMenuItem(
                      child: Wrap(
                    children: const [
                      Icon(Icons.attach_money),
                      SizedBox(width: 10),
                      Text('New income')
                    ],
                  )),
                  PopupMenuItem(
                      child: Wrap(
                    children: const [
                      Icon(Icons.add_chart),
                      SizedBox(width: 10),
                      Text('New investment')
                    ],
                  )),
                ]);
          },
          child: const Icon(
            Icons.add_circle,
            size: 50,
          ),
        ),
      ),
    );
  }
}
